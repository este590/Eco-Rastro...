# ECO-RASTRO Android

Proyecto Android inicial para ECO-RASTRO.

## Generar el APK desde GitHub

1. Crea un repositorio de GitHub.
2. Sube este ZIP a la raíz del repositorio con el nombre exacto `Eco-Rastro-GitHub-Android.zip`.
3. Crea el archivo `.github/workflows/build-apk.yml` con el workflow incluido en este proyecto.
4. Ve a Actions y ejecuta “Construir APK ECO-RASTRO”.
5. Descarga el artefacto `ECO-RASTRO-APK`; dentro está `app-debug.apk`.

La configuración fija tanto Java como Kotlin en JVM 17 para evitar incompatibilidad de destinos JVM.

Los registros y publicaciones se guardan localmente en el dispositivo. El muro no sincroniza publicaciones entre usuarios; para eso hace falta un backend.
